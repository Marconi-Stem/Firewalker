This library is from the AnimatedGIF Arduino GIF decoder by Larry Bank.
Released under the Apache License 2.0
[AnimatedGIF](https://github.com/bitbank2/AnimatedGIF)

It has been modified for use in CircuitPython by Mark Komus.
