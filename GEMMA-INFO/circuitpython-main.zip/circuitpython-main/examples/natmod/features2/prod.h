float prod_array(int n, float *ar);
