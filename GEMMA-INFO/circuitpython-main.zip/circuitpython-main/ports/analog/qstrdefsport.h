// This file is part of the CircuitPython project: https://circuitpython.org
//
// SPDX-FileCopyrightText: Copyright (c) 2024 Adafruit Industries LLC
//
// SPDX-License-Identifier: MIT

// Do not use #pragma once in this file; it will cause a warning during qstr generation.

// qstrs specific to this port
// *FORMAT-OFF*
